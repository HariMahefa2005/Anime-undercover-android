# Anime Undercover — Édition Interface Classique

Projet Android complet (`com.animeundercover.multiverse`) prêt à être compilé automatiquement sur **GitHub Actions**.

## 🚀 Comment générer l'APK sur GitHub (sans Android Studio)

1. Créez un nouveau dépôt (repository) sur **GitHub**.
2. Décompressez ce fichier `.zip` et envoyez tous les fichiers (y compris le dossier caché `.github/workflows/build-apk.yml`) sur votre dépôt GitHub.
3. Allez dans l'onglet **Actions** de votre dépôt GitHub.
4. Le workflow **Build Android APK** se lance automatiquement à chaque envoi (`push`) ou manuellement via le bouton **Run workflow**.
5. Une fois la compilation terminée (environ 1 à 2 minutes), cliquez sur l'exécution puis téléchargez **`Anime-Undercover-APK`** dans la section **Artifacts** en bas de la page.
